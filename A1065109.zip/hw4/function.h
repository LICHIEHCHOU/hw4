void randnum();
void display();
