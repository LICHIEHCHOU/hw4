#ifndef struct Data

#include<stdio.h>
#include<stdlib.h>

#include <allegro5/allegro.h>
#include <allegro5/allegro_image.h>

// Definition of display size
#define DISPLAY_WIDTH   900
#define DISPLAY_HEIGHT  900


#include<time.h>
#include<limits.h>
#include<math.h>
#define Row 9
#define Col 9


struct CANDY {
    int array[Col];
} CANDY[Row];


#endif // headers
